﻿using System;
using System.Windows.Forms;

namespace StringProcessingWinForm
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;
        private TextBox txtInputString;
        private TextBox txtInputNumber;
        private Label lblString;
        private Label lblNumber;
        private Button btnSubmit;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.txtInputString = new TextBox();
            this.txtInputNumber = new TextBox();
            this.lblString = new Label();
            this.lblNumber = new Label();
            this.btnSubmit = new Button();

            // 
            // lblString
            // 
            this.lblString.AutoSize = true;
            this.lblString.Location = new System.Drawing.Point(30, 30);
            this.lblString.Name = "lblString";
            this.lblString.Size = new System.Drawing.Size(130, 20);
            this.lblString.Text = "Enter string (S) [A-Z]:";

            // 
            // txtInputString
            // 
            this.txtInputString.Location = new System.Drawing.Point(200, 30);
            this.txtInputString.Size = new System.Drawing.Size(100, 26);

            // 
            // lblNumber
            // 
            this.lblNumber.AutoSize = true;
            this.lblNumber.Location = new System.Drawing.Point(30, 70);
            this.lblNumber.Name = "lblNumber";
            this.lblNumber.Size = new System.Drawing.Size(140, 20);
            this.lblNumber.Text = "Enter number (N) [-25; 25]:";

            // 
            // txtInputNumber
            // 
            this.txtInputNumber.Location = new System.Drawing.Point(200, 70);
            this.txtInputNumber.Size = new System.Drawing.Size(100, 16);

            // 
            // btnSubmit
            // 
            this.btnSubmit.Location = new System.Drawing.Point(150, 120);
            this.btnSubmit.Size = new System.Drawing.Size(100, 30);
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);

            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(420, 200);
            this.Controls.Add(this.lblString);
            this.Controls.Add(this.txtInputString);
            this.Controls.Add(this.lblNumber);
            this.Controls.Add(this.txtInputNumber);
            this.Controls.Add(this.btnSubmit);
            this.Name = "Form1";
            this.Text = "String Processing Validator";
        }
    }
}
