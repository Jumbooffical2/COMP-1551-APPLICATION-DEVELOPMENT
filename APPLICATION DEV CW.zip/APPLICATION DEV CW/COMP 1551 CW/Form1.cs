using System;
using System.Linq;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace StringProcessingWinForm
{
    public partial class Form1 : Form
    {
        private string _inputString;
        private int _shiftValue;
        private string _encodedOutput;

        public string InputString
        {
            get => _inputString;
            private set
            {
                if (!Regex.IsMatch(value, "^[A-Z]+$") || value.Length > 40)
                    throw new ArgumentException("String must contain only capital letters (A-Z) and be no longer than 40 characters.");
                _inputString = value;
            }
        }

        public int ShiftValue
        {
            get => _shiftValue;
            private set
            {
                if (value < -25 || value > 25)
                    throw new ArgumentException("Shift value must be between -25 and 25.");
                _shiftValue = value;
            }
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                InputString = txtInputString.Text.Trim();
                ShiftValue = int.Parse(txtInputNumber.Text.Trim());

                _encodedOutput = Encode(InputString, ShiftValue);

                string codesInfo = $"Input accepted!\nS = {InputString}\nN = {ShiftValue}\n" +
                                   $"Encoded Output = {Print()}\n" +
                                   $"Input ASCII Codes: {string.Join(", ", InputCode())}\n" +
                                   $"Output ASCII Codes: {string.Join(", ", OutputCode())}\n" +
                                   $"Sorted Input String: {Sort()}";

                MessageBox.Show(codesInfo, "Result", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private string Encode(string input, int shift)
        {
            char[] result = new char[input.Length];

            for (int i = 0; i < input.Length; i++)
            {
                int offset = ((input[i] - 'A') + shift) % 26;
                if (offset < 0)
                    offset += 26;

                result[i] = (char)('A' + offset);
            }

            return new string(result);
        }

        public string Print()
        {
            return _encodedOutput;
        }

        public int[] InputCode()
        {
            return InputString.Select(c => (int)c).ToArray();
        }

        public int[] OutputCode()
        {
            return _encodedOutput.Select(c => (int)c).ToArray();
        }

        public string Sort()
        {
            char[] chars = InputString.ToCharArray();
            Array.Sort(chars);
            return new string(chars);
        }
    }
}
